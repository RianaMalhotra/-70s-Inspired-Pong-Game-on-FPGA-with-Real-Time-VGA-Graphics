from PIL import Image

#--- CONFIG ---
W, H = 45, 45                   # sprite size
IMAGE_NAME = "ball.jpg"         # your input image (same folder)
MIF_NAME = "ball.mif"           # output file name

#--- LOAD & RESIZE IMAGE ---
img = Image.open(IMAGE_NAME)
img = img.resize((W, H))        # resize image to fit memory
img = img.convert("RGB")        # ensure RGB format

#--- Convert to 3 bits per channel (0–7 range) ---
def to_3bit(val):
    return int(round((val / 255) * 7))

pixels = list(img.getdata())

#--- Write MIF Header ---
with open(MIF_NAME, "w") as f:
    f.write(f"WIDTH=9;\n")             # 9 bits per pixel (RRR GGG BBB)
    f.write(f"DEPTH={W * H};\n")       # total pixels = 2025
    f.write("ADDRESS_RADIX=UNS;\n")
    f.write("DATA_RADIX=UNS;\n")
    f.write("CONTENT BEGIN\n")

    # --- Convert and write each pixel ---
    for i, (r, g, b) in enumerate(pixels):
        r3 = to_3bit(r)
        g3 = to_3bit(g)
        b3 = to_3bit(b)
        value = (r3 << 6) | (g3 << 3) | b3   # pack as RRR GGG BBB
        f.write(f"    {i}: {value};\n")

    f.write("END;\n")

print(f"✅ Created {MIF_NAME} successfully ({W}x{H}, {W*H} pixels)")
